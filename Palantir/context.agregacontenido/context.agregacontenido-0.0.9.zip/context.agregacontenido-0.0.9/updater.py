#!/usr/bin/env python
# -*- coding: UTF-8 -*-

import urllib 
import time, datetime
import sys, re
import xbmc, xbmcplugin, xbmcgui, xbmcaddon, xbmcvfs
import os
from default import fillPluginItems

ID = "context.agregacontenido"
ADDON = xbmcaddon.Addon(ID)
PATH = ADDON.getAddonInfo('path')

PATTERNS_FOR_DELETE = ADDON.getSetting('patterns_delete') if ADDON.getSetting('patterns_delete') else "[(].+?[)],[[].+?[]]"

IS_EDIT = ADDON.getSetting('is_edit') if ADDON.getSetting('is_edit') else "false"

Categorias = ["Series","Temporada","Películas"]
DIRECTORY = xbmc.translatePath(ADDON.getSetting('directory'))

for [ruta,directorios,archivos] in os.walk(DIRECTORY, topdown=True):
    for archivo in archivos:
        if archivo.endswith(".txt"):
			leer_txt = open(ruta+'/'+archivo,"r")
			lista = str(leer_txt.read()).split(';')
			if len(lista) == 4:
				[media_title,category,uri,foldername] = lista
				fillPluginItems(uri, category, media_title,foldername)
				#message = "'%s'" % media_title
				#xbmc.executebuiltin("Notification(\"Se ha actualizado\", \"%s\")" % message)
			if len(lista) == 3:
				[media_title,category,uri] = lista
				xbmc.log('ANTES DE ENTRAR CON SERVICE  ' + category,xbmc.LOGNOTICE)
				fillPluginItems(uri, category.decode('utf-8'), media_title)
				#message = "'%s'" % media_title
				#xbmc.executebuiltin("Notification(\"Se ha actualizado\", \"%s\")" % message)
xbmc.executebuiltin('XBMC.UpdateLibrary(video)')