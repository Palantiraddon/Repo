#!/usr/bin/env python
# -*- coding: UTF-8 -*-

import urllib 
import time, datetime
import sys, re
import xbmc, xbmcplugin, xbmcgui, xbmcaddon, xbmcvfs
import os

ID = "context.agregacontenido"
ADDON = xbmcaddon.Addon(ID)
PATH = ADDON.getAddonInfo('path')

PATTERNS_FOR_DELETE = ADDON.getSetting('patterns_delete') if ADDON.getSetting('patterns_delete') else "[(].+?[)],[[].+?[]]"

IS_EDIT = ADDON.getSetting('is_edit') if ADDON.getSetting('is_edit') else "false"

Categorias = ["Series","Temporada","Películas"]
DIRECTORY = xbmc.translatePath(ADDON.getSetting('directory'))

if not xbmcvfs.exists(os.path.join(DIRECTORY,Categorias[0])): 
	xbmcvfs.mkdirs(os.path.join(DIRECTORY,Categorias[0]))
if not xbmcvfs.exists(os.path.join(DIRECTORY,Categorias[2])): 
	xbmcvfs.mkdirs(os.path.join(DIRECTORY,Categorias[2]))


xbmc.executebuiltin('XBMC.UpdateLibrary(video)')
xbmc.executebuiltin("ReloadSkin()", True)


def continuar():
	while xbmc.Player().isPlaying() == 0:
		path =xbmc.getInfoLabel('ListItem.FileNameAndPath')
		if path[-5:] == '.strm':
			porcentaje = xbmc.getInfoLabel('ListItem.PercentPlayed')
		if path[-5:] != '.strm' and path[-5:] !='':
			if 'porcentaje' in locals():
				del porcentaje
		xbmc.sleep(200)
	if 'porcentaje' in locals():
		if int(porcentaje) > 0:
			while xbmc.Player().isPlaying() == 1:
				punto = xbmc.Player().getTime()
				xbmc.sleep(200)
				if xbmc.Player().getTime() > punto:
					break	
			xbmc.Player().pause()
			tiempo = xbmc.Player().getTotalTime()
			resume_time = float(tiempo) * (float(porcentaje)-0.5)/100
			ret = xbmcgui.Dialog().select("Has visto el " + porcentaje + '%', ['Reanudar vídeo en '+str(datetime.timedelta(seconds=int(resume_time))),'Reproducir desde el principio'])
			if ret == 0:
				xbmc.Player().seekTime(float(resume_time))
				xbmc.Player().pause()
			if ret == 1:
				xbmc.Player().pause()
			while xbmc.Player().isPlaying() == 1:
				xbmc.sleep(1000)
	else:
		while xbmc.Player().isPlaying() == 1:
			xbmc.sleep(1000)
	if 'porcentaje' in locals():
		del porcentaje
	xbmc.sleep(1000)
	continuar()
continuar()
