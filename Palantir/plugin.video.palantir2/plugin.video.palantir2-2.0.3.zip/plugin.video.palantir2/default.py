# -*- coding: utf-8 -*-

import xbmcgui
xbmcgui.Dialog().ok("Nuevo Palantir", "Muy pronto...")